import UIKit

class BlendModeCell: UICollectionViewCell {

    @IBOutlet weak var modeImage: UIImageView!
    @IBOutlet weak var modeName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

}
