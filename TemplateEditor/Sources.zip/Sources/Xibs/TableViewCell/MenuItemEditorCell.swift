import UIKit

class MenuItemEditorCell: UITableViewCell {

    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var editBtn: UIControl!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
}
